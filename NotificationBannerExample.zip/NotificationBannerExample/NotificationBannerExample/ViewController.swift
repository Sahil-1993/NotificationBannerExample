//
//  ViewController.swift
//  NotificationBannerExample
//
//  Created by Sahil Arora on 2020-11-17.
//  Copyright © 2020 Sahil Arora. All rights reserved.
//

import UIKit
import NotificationBannerSwift


class ViewController: UIViewController {
    
    public let sideViewSize = 50.0

    private  var image:UIImageView = {
        
        let imgview = UIImageView()
        imgview.image = UIImage(named: "images")
        imgview.contentMode = .scaleAspectFill
        imgview.layer.cornerRadius = 25.0
        imgview.clipsToBounds = true
        
        return imgview
        
    }()
    
    private var custonButton:UIButton = {
        
        let btn = UIButton()
        
        btn.setTitle("Get Notification", for: .normal)
        btn.backgroundColor = UIColor.cyan
        btn.layer.cornerRadius = 10.0
        btn.clipsToBounds = true
        btn.addTarget(self, action: #selector(action_GetNotification), for: .touchUpInside)
        return btn
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(custonButton)
       
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
         custonButton.frame = CGRect(x: 30, y: (view.frame.size.height-60)/2, width: (view.frame.size.width-60), height: 60)
        
    }
//Button Action
@objc func action_GetNotification()
{
    showNotification()
}
    //Notification Banner Layout
    func showNotification(){
        let   notificationBanner =  GrowingNotificationBanner(title: "You have a new Message", subtitle: "Sahil: Hey! wanna catch up for movie. I am free after 3'o clock, just lemme know", leftView: image, rightView: nil, style: .info, colors: nil, iconPosition: .top, sideViewSize:CGFloat(self.sideViewSize))
        DispatchQueue.main.async {
            notificationBanner.show()
        }
        
    }
}

